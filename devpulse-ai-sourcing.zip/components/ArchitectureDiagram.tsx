
import React from 'react';
import { Search, Cpu, FileText, CheckCircle, Users } from 'lucide-react';

const ArchitectureDiagram: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm overflow-x-auto">
      <h3 className="text-lg font-semibold mb-6 text-slate-800">Agentic Architecture Workflow</h3>
      <div className="flex items-center justify-between min-w-[600px] space-x-4">
        
        {/* Requirement Parser */}
        <div className="flex flex-col items-center flex-1">
          <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-2">
            <FileText className="text-blue-600 w-6 h-6" />
          </div>
          <span className="text-sm font-medium">Requirement Parser</span>
          <p className="text-xs text-slate-500 text-center mt-1">NLP Parsing & Schema Extraction</p>
        </div>

        <div className="h-px w-8 bg-slate-300"></div>

        {/* Discovery Agent */}
        <div className="flex flex-col items-center flex-1">
          <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-2">
            <Search className="text-purple-600 w-6 h-6" />
          </div>
          <span className="text-sm font-medium">Discovery Agent</span>
          <p className="text-xs text-slate-500 text-center mt-1">Google Grounding & Open Source Scraping</p>
        </div>

        <div className="h-px w-8 bg-slate-300"></div>

        {/* Evaluation Agent */}
        <div className="flex flex-col items-center flex-1">
          <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center mb-2">
            <Cpu className="text-indigo-600 w-6 h-6" />
          </div>
          <span className="text-sm font-medium">Evaluation Agent</span>
          <p className="text-xs text-slate-500 text-center mt-1">Skill Verification & Activity Analysis</p>
        </div>

        <div className="h-px w-8 bg-slate-300"></div>

        {/* Ranking & Results */}
        <div className="flex flex-col items-center flex-1">
          <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-2">
            <Users className="text-green-600 w-6 h-6" />
          </div>
          <span className="text-sm font-medium">Ranking Module</span>
          <p className="text-xs text-slate-500 text-center mt-1">Alignment Scoring & Explanation</p>
        </div>

      </div>
    </div>
  );
};

export default ArchitectureDiagram;
