
import React from 'react';
import { AgentStatus, AgentStep } from '../types';
import { Loader2, CheckCircle2, Circle } from 'lucide-react';

const STEPS: AgentStep[] = [
  { id: AgentStatus.PARSING, label: 'Parsing Requirements', description: 'Deconstructing hiring request into technical parameters.' },
  { id: AgentStatus.DISCOVERING, label: 'Data Discovery', description: 'Scanning GitHub, Stack Overflow, and technical blogs.' },
  { id: AgentStatus.EVALUATING, label: 'Skill Evaluation', description: 'Validating experience via commit history and public projects.' },
  { id: AgentStatus.RANKING, label: 'Ranking & Matching', description: 'Applying matching algorithms to finalize recommendations.' },
];

interface Props {
  currentStatus: AgentStatus;
}

const AgentStatusIndicator: React.FC<Props> = ({ currentStatus }) => {
  if (currentStatus === AgentStatus.IDLE || currentStatus === AgentStatus.COMPLETED) return null;

  const activeIndex = STEPS.findIndex(s => s.id === currentStatus);

  return (
    <div className="space-y-4 py-4 px-6 bg-slate-50 rounded-xl border border-slate-200">
      <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Agent Network Activity</h3>
      <div className="space-y-4">
        {STEPS.map((step, idx) => {
          const isCompleted = idx < activeIndex;
          const isActive = idx === activeIndex;

          return (
            <div key={step.id} className="flex items-start gap-3">
              <div className="mt-1">
                {isCompleted ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : isActive ? (
                  <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
                ) : (
                  <Circle className="w-5 h-5 text-slate-300" />
                )}
              </div>
              <div>
                <p className={`text-sm font-semibold ${isActive ? 'text-blue-600' : 'text-slate-700'}`}>
                  {step.label}
                </p>
                <p className="text-xs text-slate-500">{step.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AgentStatusIndicator;
