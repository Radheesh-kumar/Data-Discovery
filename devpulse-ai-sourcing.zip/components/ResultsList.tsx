
import React from 'react';
import { Candidate } from '../types';
import { ExternalLink, Star, Award, Search, Info } from 'lucide-react';

interface Props {
  candidates: Candidate[];
}

const ResultsList: React.FC<Props> = ({ candidates }) => {
  if (!candidates.length) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">Top Recommended Talent</h2>
        <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">
          {candidates.length} Profiles Found
        </span>
      </div>
      <div className="grid gap-6">
        {candidates.map((candidate, idx) => (
          <div key={idx} className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-blue-300 transition-colors shadow-sm">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">{candidate.name}</h3>
                  <p className="text-sm text-slate-600">{candidate.headline}</p>
                </div>
                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-1 text-blue-600 font-bold">
                    <Star className="w-4 h-4 fill-current" />
                    <span>{candidate.score}% Match</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {candidate.skills.map((skill, sIdx) => (
                  <span key={sIdx} className="px-2 py-1 bg-slate-100 text-slate-600 text-xs rounded-md">
                    {skill}
                  </span>
                ))}
              </div>

              <div className="bg-blue-50 p-4 rounded-lg mb-4 border border-blue-100">
                <div className="flex items-center gap-2 mb-2 text-blue-800 text-sm font-bold">
                  <Info className="w-4 h-4" />
                  Agent Reasoning
                </div>
                <p className="text-sm text-slate-700 leading-relaxed mb-3">
                  {candidate.explanation}
                </p>
                <div className="space-y-1">
                  {candidate.evidence.map((ev, eIdx) => (
                    <div key={eIdx} className="flex items-center gap-2 text-xs text-slate-600">
                      <Award className="w-3 h-3 text-blue-400" />
                      {ev}
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-4">
                {candidate.platforms.map((platform, pIdx) => (
                  <a
                    key={pIdx}
                    href={platform.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:underline"
                  >
                    <ExternalLink className="w-3 h-3" />
                    {platform.name}
                  </a>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResultsList;
