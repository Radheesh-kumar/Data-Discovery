
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { HiringRequirements, Candidate } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const parseHiringRequest = async (prompt: string): Promise<HiringRequirements> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this hiring request and extract structured requirements: "${prompt}"`,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          skills: { type: Type.ARRAY, items: { type: Type.STRING } },
          technologies: { type: Type.ARRAY, items: { type: Type.STRING } },
          experienceLevel: { type: Type.STRING, enum: ['Junior', 'Mid', 'Senior', 'Lead', 'Unspecified'] },
          quantity: { type: Type.INTEGER },
          location: { type: Type.STRING },
        },
        required: ['skills', 'technologies', 'experienceLevel', 'quantity']
      }
    }
  });

  const parsed = JSON.parse(response.text || '{}');
  return {
    ...parsed,
    originalRequest: prompt
  };
};

export const discoverCandidates = async (requirements: HiringRequirements): Promise<any[]> => {
  const searchQuery = `Find public profiles of software developers with skills in ${requirements.skills.join(', ')} and technologies like ${requirements.technologies.join(', ')} on GitHub, GitLab, StackOverflow, or LinkedIn. Search for active contributors and portfolio sites.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: searchQuery,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  // Extract grounding chunks which contain URLs and snippets
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  return chunks;
};

export const evaluateAndRankCandidates = async (
  requirements: HiringRequirements, 
  discoveryData: any[]
): Promise<Candidate[]> => {
  const context = JSON.stringify(discoveryData);
  const prompt = `
    Based on the following search data and the original hiring requirements, identify the top unique candidates.
    
    Hiring Requirements:
    - Skills: ${requirements.skills.join(', ')}
    - Technologies: ${requirements.technologies.join(', ')}
    - Level: ${requirements.experienceLevel}
    
    Discovery Data:
    ${context}
    
    Provide a list of up to 5 candidates in JSON format. Each candidate must include:
    - name: Full name or username
    - headline: Professional summary
    - skills: List of detected skills
    - platforms: Array of objects {name, url}
    - score: 0-100 based on alignment
    - explanation: Why they were selected
    - evidence: List of specific proofs (e.g., "Active AWS repository", "Top 5% in NoSQL on Stack Overflow")
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            headline: { type: Type.STRING },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            platforms: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  url: { type: Type.STRING }
                }
              }
            },
            score: { type: Type.NUMBER },
            explanation: { type: Type.STRING },
            evidence: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ['name', 'headline', 'skills', 'platforms', 'score', 'explanation', 'evidence']
        }
      }
    }
  });

  return JSON.parse(response.text || '[]');
};
